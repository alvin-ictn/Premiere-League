const menu = `
<li><a class="waves-effect" href="#home">Home</a></li>
<li><a class="waves-effect" href="#score">Score</a></li>
<li><a class="waves-effect" href="#favorite">Favorite</a></li>
`;

export default menu;
